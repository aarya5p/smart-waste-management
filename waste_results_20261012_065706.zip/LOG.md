# Experiment Log

| Date | Model | Settings | Seed | Accuracy | Macro F1 | Notes |
|------|-------|----------|------|----------|----------|-------|
| 2026-10-12 | mobilenet_v2 | frozen, 30ep(max), bs32, lr0.001, img224, Adam, class-weighted CE, early-stop p5 | 42 | 0.8235 (val) | - (see evaluate.py) | train | best epoch 19/24 | val loss 0.5315 | 5.6 min on cuda | mobilenet_v2_frozen_seed42 |
| 2026-10-12 | mobilenet_v2 | frozen, eval on splits/val.csv, img224 | 42 | 0.8235 | 0.8015 | eval | macro P 0.7983 R 0.8220 | params 2,231,558 | ckpt 8.73 MB | GMACs 0.31 | 5.1 ms/img on cuda (laptop, not for report) | mobilenet_v2_frozen_seed42 |
| 2026-10-12 | mobilenet_v2 | frozen, eval on splits/test.csv, img224 | 42 | 0.8107 | 0.7842 | eval | macro P 0.7811 R 0.8044 | params 2,231,558 | ckpt 8.73 MB | GMACs 0.31 | 5.3 ms/img on cuda (laptop, not for report) | mobilenet_v2_frozen_seed42 |
